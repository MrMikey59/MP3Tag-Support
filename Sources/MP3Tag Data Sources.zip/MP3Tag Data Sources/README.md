# mp3tag_data_sources

[Beatport\.com WSS by stevehero \[Release, Single Track & Artwork tagging\] \- Development / Web Sources Scripts \- Mp3tag Community](https://community.mp3tag.de/t/beatport-com-wss-by-stevehero-release-single-track-artwork-tagging/12568)

[Traxsource web tag scripts \- Development / Web Sources Scripts \- Mp3tag Community](https://community.mp3tag.de/t/traxsource-web-tag-scripts/53011/3)

[\[WS\] iTunes \- Development / Web Sources Scripts \- Mp3tag Community](https://community.mp3tag.de/t/ws-itunes/13478/323)

