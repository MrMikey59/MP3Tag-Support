# Mp3tag Actions Pack

## About

For example, user can write an action that will Uppecase Every First Letter In Every Word, or will create a folder with the "*[year] %artist% - %albumname%*" name and put audiofiles here. Basically it saves a lot of time.

Actions is a powerful feature, but require to know both and learn in-build functions. For most users it is complicated. To make things 'worse' - Mp3Tag has two different syntaxes with different escaping rules and logic.

That repository provides a **pack of prebuild actions**. You *don't need to learn programming*, just copypaste those actions into your program and user them on click.

## Important
* That pack *is not a magic wand* that will satisfy any need and can handle any situation. Do not expect this pack will solve all problem.

* Before using those actions - create a backup folder for your music files and play around with actions before using them on 'real' files.

* If you have a special case and that pack cannot help you, then you mush either [learn the syntax](https://community.mp3tag.de/t/actions-and-batch-operations/967/12) or ask for the help on the [forum](https://community.mp3tag.de/).

## FAQ

### Q. I am tired to select dozen actions over and over, how can I simplify selection?
**A1**. Manually copypaste actions into one single action (via any text editor), see 00_MAIN.mta as an example.

**A2**. Create _an action group_. [See the screenshot](/help/help002.png).

### Q. What is 00_MAIN action?
**A**. This is my personal action I am using to clean music in my collection. You can use it as a guideline how you can combine various actions in one file.
